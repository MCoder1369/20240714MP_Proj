﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParsingDemo
{
    interface IDonations
    {
        List<string> Donor { get; set; }
        List<decimal> Amount { get; set; }

    }
}
