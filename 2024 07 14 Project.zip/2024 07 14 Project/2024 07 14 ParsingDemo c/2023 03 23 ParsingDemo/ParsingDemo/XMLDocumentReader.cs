﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace ParsingDemo
{
    public class XMLDocumentReader : IDocument<MP>
    {
        private List<MP> myMPs = new List<MP>();

        public void LoadXml()
        {
            // Load the XML document
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            XDocument xml = XDocument.Load(@"https://www.theyworkforyou.com/pwdata/scrapedxml/regmem/regmem2021-12-13.xml");

            // Iterate through each <regmem> element in the XML
            foreach (XElement regmem in xml.Root.Elements("regmem"))
            {
                // Extract the member's ID and name
                int id = Convert.ToInt32(regmem.Attribute("personid").Value.Split('/')[2]);
                string name = regmem.Attribute("membername").Value;

                // Iterate through each <category> element
                foreach (XElement category in regmem.Elements("category"))
                {
                    // Check if the category is "Employment and earnings"
                    if (category.Attribute("name")?.Value == "Employment and earnings")
                    {
                        // Iterate through each <record> element
                        foreach (XElement record in category.Elements("record"))
                        {
                            // Iterate through each <item> element
                            foreach (XElement item in record.Elements("item"))
                            {
                                List<string> donor = new List<string>();
                                List<decimal> amounts = new List<decimal>();

                                // Extract donor and amount from <item>
                                string itemValue = item.Value.Trim();

                                // Find "received" to start parsing amount
                                int receivedIndex = itemValue.IndexOf("received");
                                if (receivedIndex != -1)
                                {
                                    // Extract amount after "received"
                                    string amountString = itemValue.Substring(receivedIndex + "received".Length).Trim();
                                    Match match = Regex.Match(amountString, @"(\d+(\.\d+)?)");

                                    if (match.Success)
                                    {
                                        decimal amount = decimal.Parse(match.Value);
                                        amounts.Add(amount);
                                    }
                                }

                                // Find "from" to start parsing donor
                                int fromIndex = itemValue.IndexOf("from");
                                if (fromIndex != -1)
                                {
                                    // Extract donor after "from"
                                    string donorString = itemValue.Substring(fromIndex + "from".Length).Trim();
                                    int commaIndex = donorString.IndexOf(",");
                                    if (commaIndex != -1)
                                    {
                                        donorString = donorString.Substring(0, commaIndex);
                                    }
                                    donor.AddRange(donorString.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
                                }

                                // Add MP to the list
                                myMPs.Add(new MP { Id = id, Name = name, Donor = donor, Amount = amounts });
                            }
                        }
                    }
                }
            }
        }

        public List<MP> GetAllData()
        {
            LoadXml();
            return myMPs;
        }
    }

}

