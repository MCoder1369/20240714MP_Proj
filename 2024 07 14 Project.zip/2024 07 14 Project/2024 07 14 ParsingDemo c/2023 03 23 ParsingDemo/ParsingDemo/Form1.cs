﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ParsingDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            XMLDocumentReader xmlreader = new XMLDocumentReader();

            //LoadXml();

            // Create a DataTable to hold the report data
            DataTable reportData = new DataTable();
            reportData.Columns.Add("Name", typeof(string));
            reportData.Columns.Add("Party Affliation", typeof(string));
            reportData.Columns.Add("Donor", typeof(string));
            reportData.Columns.Add("Amount", typeof(decimal));

            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = xmlreader.GetAllData();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
