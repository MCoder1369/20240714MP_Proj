﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParsingDemo
{
    public class MP : IPerson, IDonations
    {
        public List<decimal> Amount{ get; set; }

        public List<string> Donor { get; set; }


        public int Id { get; set; }


        public string Name { get; set; }

        public string Donors { get { return string.Join(" ", Donor); } }
        public string Amounts { get { return string.Join(", ", Amount); } }

    }
}
