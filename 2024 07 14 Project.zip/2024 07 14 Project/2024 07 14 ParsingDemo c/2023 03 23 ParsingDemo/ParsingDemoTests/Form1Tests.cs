﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParsingDemo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ParsingDemo.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void GetAllData_ReadDataFromXMLFile_ReturnsListOfMPs()
        {
            //Arrange
            XMLDocumentReader xmlReader = new XMLDocumentReader();
            List<MP> myMPs = new List<MP>();

            //Act
            myMPs = xmlReader.GetAllData();

            //Assert
            Assert.IsNotNull(myMPs);

        }

        [TestMethod()]
        public void LoadXml()
        {
            //Arrange
            XMLDocumentReader documentReader = new XMLDocumentReader();

            //Act
            var result = documentReader.GetAllData();

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(2069, result.Count);
            Assert.AreEqual(result.First().Id, 10001);
            Assert.AreEqual(result.First().Name, "Diane Abbott");
        }

        [TestMethod()]
        public void GetDocument()
        {
            //Arrange
            XDocument xml = new XDocument();

            //Act
            xml = XDocument.Load(@"https://www.theyworkforyou.com/pwdata/scrapedxml/regmem/regmem2021-12-13.xml");

            //Assert
            Assert.IsNotNull(xml);
        }

        [TestMethod()]
        public void DonationNotZero()
        {
            //Arrange
            XMLDocumentReader documentReader = new XMLDocumentReader();

            //Act
            var result = documentReader.GetAllData();

            //Assert
            Assert.AreNotEqual(result.First().Amount, 0);
        }

        [TestMethod()]
        public void AddMPs()
        {
            //Arrange
            List<MP> myMPs = new List<MP>();
            XDocument xml = XDocument.Load(@"https://www.theyworkforyou.com/pwdata/scrapedxml/regmem/regmem2021-12-13.xml");

            //Act
            foreach (XElement regmem in xml.Root.Elements("regmem"))
            {
                // Extract the member's name, ID, and party affiliation
                string urlid = regmem.Attribute("personid").Value;
                string del = "/";
                string[] spliturlid = urlid.Split(del.ToCharArray());
                int id = Convert.ToInt16(spliturlid[2]);

                string name = regmem.Attribute("membername").Value;
                string partyAffiliation = "N/A";

                // Iterate through each <category> element
                foreach (XElement category in regmem.Elements("category"))
                {
                    if (category.Attribute("name").Value == "Employment and earnings")
                    {
                        // Extract the donor and amount from the <record> element
                        foreach (XElement record in category.Elements("record"))
                        {
                            foreach (XElement item in record.Elements("item"))
                            {
                                string[] itemParts = item.Value.Split(' ');
                                List<string> donor = new List<string>();
                                List<decimal> amount = new List<decimal>();
                                decimal _amount = 0;
                                string pattern1 = @"(\d+\.\d+)";
                                string pattern2 = @"(\d+)";

                                Match match;

                                // Extract the donor name and amount
                                for (int i = 0; i < itemParts.Length; i++)
                                {
                                    if (itemParts[i] == "received")
                                    {

                                        decimal.TryParse(itemParts[i + 1], out _amount);


                                        match = Regex.Match(itemParts[i + 1], pattern2);

                                        if (match.Success) decimal.TryParse(match.Value, out _amount);
                                        amount.Add(_amount);
                                    }
                                    if (itemParts[i] == "from")
                                    {
                                        for (int j = i + 1; j < itemParts.Length; j++)
                                        {
                                            if (itemParts[j] == ",")
                                            {
                                                break;
                                            }
                                            donor.Add(itemParts[j]);
                                        }
                                    }
                                }

                                // Add a new MP to the MP list
                                amount.Add(_amount);
                                myMPs.Add(new MP { Id = id, Name = name, Donor = donor, Amount = amount });



                            }
                        }


                    }
                }

                
                

            }

            //Assert

            Assert.IsNotNull(myMPs);
        }

        



    }
}